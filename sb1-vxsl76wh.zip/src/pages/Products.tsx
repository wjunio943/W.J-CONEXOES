import React, { useState } from 'react';
import { Link } from 'react-router-dom';

// Sample product categories and products
const categories = [
  { id: 1, name: 'Conexões para Freios' },
  { id: 2, name: 'Válvulas Pneumáticas' },
  { id: 3, name: 'Mangueiras' },
  { id: 4, name: 'Acessórios' },
];

const products = [
  {
    id: 1,
    name: 'Conexão de Freio M16',
    category: 1,
    description: 'Conexão de freio pneumático M16 para caminhões pesados',
    image: 'https://placehold.co/300x200',
    specifications: ['Material: Aço', 'Rosca: M16', 'Pressão máxima: 150 PSI'],
  },
  {
    id: 2,
    name: 'Conexão Rápida 1/2"',
    category: 1,
    description: 'Conexão rápida de 1/2 polegada para sistema de freio',
    image: 'https://placehold.co/300x200',
    specifications: ['Material: Latão', 'Diâmetro: 1/2"', 'Tipo: Engate rápido'],
  },
  // Add more products...
];

const Products = () => {
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  const filteredProducts = products.filter(product => {
    const matchesCategory = selectedCategory ? product.category === selectedCategory : true;
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Nossos Produtos</h1>

      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="md:col-span-3">
          <input
            type="text"
            placeholder="Buscar produtos..."
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div>
          <select
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            value={selectedCategory || ''}
            onChange={(e) => setSelectedCategory(e.target.value ? Number(e.target.value) : null)}
          >
            <option value="">Todas as categorias</option>
            {categories.map(category => (
              <option key={category.id} value={category.id}>
                {category.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Products Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {filteredProducts.map(product => (
          <Link
            key={product.id}
            to={`/produtos/${product.id}`}
            className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition"
          >
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-48 object-cover"
            />
            <div className="p-4">
              <h3 className="text-xl font-semibold mb-2">{product.name}</h3>
              <p className="text-gray-600 mb-4">{product.description}</p>
              <ul className="text-sm text-gray-500">
                {product.specifications.map((spec, index) => (
                  <li key={index} className="mb-1">• {spec}</li>
                ))}
              </ul>
              <button className="mt-4 w-full bg-blue-800 text-white px-4 py-2 rounded hover:bg-blue-700 transition">
                Ver Detalhes
              </button>
            </div>
          </Link>
        ))}
      </div>

      {filteredProducts.length === 0 && (
        <div className="text-center py-8">
          <p className="text-gray-600">Nenhum produto encontrado.</p>
        </div>
      )}
    </div>
  );
};

export default Products;