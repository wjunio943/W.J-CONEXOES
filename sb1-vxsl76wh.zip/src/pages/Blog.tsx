import React from 'react';

const blogPosts = [
  {
    id: 1,
    title: 'Como escolher a conexão de freio ideal para seu caminhão',
    excerpt: 'Guia completo para ajudar você a selecionar a conexão mais adequada...',
    date: '2023-11-15',
    image: 'https://placehold.co/600x400',
    category: 'Guia Técnico',
  },
  {
    id: 2,
    title: 'Manutenção preventiva do sistema de freios',
    excerpt: 'Aprenda as melhores práticas para manter seu sistema de freios...',
    date: '2023-11-10',
    image: 'https://placehold.co/600x400',
    category: 'Manutenção',
  },
  {
    id: 3,
    title: 'Novidades em tecnologia de freios para caminhões',
    excerpt: 'Conheça as últimas inovações em sistemas de freios...',
    date: '2023-11-05',
    image: 'https://placehold.co/600x400',
    category: 'Novidades',
  },
];

const Blog = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Blog</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {blogPosts.map(post => (
          <article key={post.id} className="bg-white rounded-lg shadow-md overflow-hidden">
            <img
              src={post.image}
              alt={post.title}
              className="w-full h-48 object-cover"
            />
            <div className="p-6">
              <div className="flex items-center mb-4">
                <span className="text-sm text-blue-800 font-semibold">{post.category}</span>
                <span className="mx-2 text-gray-400">•</span>
                <span className="text-sm text-gray-500">{post.date}</span>
              </div>
              <h2 className="text-xl font-bold mb-3">{post.title}</h2>
              <p className="text-gray-600 mb-4">{post.excerpt}</p>
              <button className="text-blue-800 font-semibold hover:text-blue-900">
                Ler mais →
              </button>
            </div>
          </article>
        ))}
      </div>

      {/* Newsletter Subscription */}
      <div className="mt-12 bg-blue-900 text-white rounded-lg p-8">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-2xl font-bold mb-4">
            Receba nossas novidades
          </h2>
          <p className="mb-6">
            Inscreva-se para receber dicas técnicas e novidades do setor
          </p>
          <form className="flex flex-col md:flex-row gap-4">
            <input
              type="email"
              placeholder="Seu e-mail"
              className="flex-grow px-4 py-2 rounded-lg text-gray-900"
            />
            <button
              type="submit"
              className="bg-white text-blue-900 px-6 py-2 rounded-lg font-semibold hover:bg-blue-100 transition"
            >
              Inscrever
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Blog;