import React from 'react';
import { useParams } from 'react-router-dom';

// Sample product data
const products = [
  {
    id: 1,
    name: 'Conexão de Freio M16',
    description: 'Conexão de freio pneumático M16 para caminhões pesados',
    longDescription: `
      A Conexão de Freio M16 é projetada especificamente para sistemas de freio pneumático
      de caminhões pesados. Fabricada com materiais de alta qualidade, esta conexão oferece
      durabilidade excepcional e segurança garantida para sua frota.
    `,
    image: 'https://placehold.co/600x400',
    gallery: [
      'https://placehold.co/600x400',
      'https://placehold.co/600x400',
      'https://placehold.co/600x400',
    ],
    specifications: [
      { label: 'Material', value: 'Aço Inoxidável' },
      { label: 'Rosca', value: 'M16' },
      { label: 'Pressão Máxima', value: '150 PSI' },
      { label: 'Temperatura de Operação', value: '-40°C a 120°C' },
    ],
    features: [
      'Alta resistência à corrosão',
      'Vedação reforçada',
      'Fácil instalação',
      'Compatível com principais marcas',
    ],
  },
  // Add more products...
];

const ProductDetail = () => {
  const { id } = useParams();
  const product = products.find(p => p.id === Number(id));

  if (!product) {
    return (
      <div className="container mx-auto px-4 py-8">
        <p>Produto não encontrado.</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Product Images */}
        <div>
          <div className="bg-white rounded-lg shadow-md overflow-hidden mb-4">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-auto"
            />
          </div>
          <div className="grid grid-cols-3 gap-4">
            {product.gallery.map((image, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden">
                <img
                  src={image}
                  alt={`${product.name} - ${index + 1}`}
                  className="w-full h-auto cursor-pointer"
                />
              </div>
            ))}
          </div>
        </div>

        {/* Product Information */}
        <div>
          <h1 className="text-3xl font-bold mb-4">{product.name}</h1>
          <p className="text-gray-600 mb-6">{product.longDescription}</p>

          {/* Specifications */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <h2 className="text-xl font-bold mb-4">Especificações Técnicas</h2>
            <div className="grid grid-cols-2 gap-4">
              {product.specifications.map((spec, index) => (
                <div key={index}>
                  <p className="font-semibold">{spec.label}</p>
                  <p className="text-gray-600">{spec.value}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Features */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <h2 className="text-xl font-bold mb-4">Características</h2>
            <ul className="list-disc list-inside text-gray-600">
              {product.features.map((feature, index) => (
                <li key={index}>{feature}</li>
              ))}
            </ul>
          </div>

          {/* Call to Action */}
          <div className="bg-blue-900 text-white rounded-lg p-6">
            <h2 className="text-xl font-bold mb-4">Interessado neste produto?</h2>
            <p className="mb-4">
              Entre em contato conosco para obter mais informações ou solicitar um orçamento.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <a
                href="https://wa.me/556299999999"
                className="bg-green-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-green-700 transition text-center"
              >
                WhatsApp
              </a>
              <button
                className="bg-white text-blue-900 px-6 py-3 rounded-lg font-semibold hover:bg-blue-100 transition"
              >
                Solicitar Orçamento
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;