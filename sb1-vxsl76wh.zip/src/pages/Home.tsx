import React from 'react';
import { Link } from 'react-router-dom';
import Slider from 'react-slick';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

const Home = () => {
  const sliderSettings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 5000,
  };

  const featuredProducts = [
    {
      id: 1,
      name: 'Conexão de Freio M16',
      description: 'Conexão de freio pneumático M16 para caminhões pesados',
      image: 'https://placehold.co/400x300',
    },
    {
      id: 2,
      name: 'Conexão Rápida 1/2"',
      description: 'Conexão rápida de 1/2 polegada para sistema de freio',
      image: 'https://placehold.co/400x300',
    },
    {
      id: 3,
      name: 'Kit Reparo Válvula',
      description: 'Kit completo para reparo de válvula de freio',
      image: 'https://placehold.co/400x300',
    },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-blue-800 text-white py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Conexões para Freios de Caminhão e Linha Pneumática
            </h1>
            <p className="text-xl mb-8">
              Qualidade e segurança para sua frota com as melhores conexões do mercado
            </p>
            <Link
              to="/produtos"
              className="bg-white text-blue-800 px-8 py-3 rounded-lg font-semibold hover:bg-blue-100 transition"
            >
              Ver Produtos
            </Link>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 bg-gray-100">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-bold mb-3">Entrega para todo o Brasil</h3>
              <p className="text-gray-600">
                Enviamos seus produtos com rapidez e segurança para qualquer lugar do país
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-bold mb-3">Atendimento Especializado</h3>
              <p className="text-gray-600">
                Equipe técnica pronta para auxiliar na escolha do produto ideal
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-bold mb-3">Produtos Certificados</h3>
              <p className="text-gray-600">
                Todas as nossas peças possuem certificação de qualidade
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-8">Produtos em Destaque</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {featuredProducts.map((product) => (
              <Link
                key={product.id}
                to={`/produtos/${product.id}`}
                className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition"
              >
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-48 object-cover"
                />
                <div className="p-4">
                  <h3 className="text-xl font-semibold mb-2">{product.name}</h3>
                  <p className="text-gray-600">{product.description}</p>
                </div>
              </Link>
            ))}
          </div>
          <div className="text-center mt-8">
            <Link
              to="/produtos"
              className="inline-block bg-blue-800 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 transition"
            >
              Ver Todos os Produtos
            </Link>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="bg-blue-900 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">
            Precisa de ajuda para escolher o produto ideal?
          </h2>
          <p className="text-xl mb-8">
            Nossa equipe está pronta para te auxiliar na melhor escolha para sua necessidade
          </p>
          <Link
            to="/contato"
            className="bg-white text-blue-900 px-8 py-3 rounded-lg font-semibold hover:bg-blue-100 transition"
          >
            Fale Conosco
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;