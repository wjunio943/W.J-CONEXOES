import React from 'react';
import { Link } from 'react-router-dom';

const About = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-bold mb-8">Sobre Nossa Empresa</h1>
        
        <div className="bg-white rounded-lg shadow-md p-8 mb-8">
          <h2 className="text-2xl font-bold mb-4">Nossa História</h2>
          <p className="text-gray-700 mb-6">
            Com mais de [X] anos de experiência no mercado de autopeças para caminhões,
            nos especializamos no fornecimento de conexões para freios e linha pneumática
            de alta qualidade. Nossa jornada começou em Goiás, e hoje atendemos clientes
            em todo o Brasil.
          </p>
          
          <h2 className="text-2xl font-bold mb-4">Missão</h2>
          <p className="text-gray-700 mb-6">
            Fornecer produtos de alta qualidade para o setor de transportes,
            garantindo a segurança e eficiência dos sistemas de freios dos
            veículos de nossos clientes.
          </p>
          
          <h2 className="text-2xl font-bold mb-4">Valores</h2>
          <ul className="list-disc list-inside text-gray-700 mb-6">
            <li>Qualidade em primeiro lugar</li>
            <li>Compromisso com a segurança</li>
            <li>Atendimento personalizado</li>
            <li>Transparência nos negócios</li>
            <li>Responsabilidade com nossos clientes</li>
          </ul>
        </div>

        <div className="bg-white rounded-lg shadow-md p-8 mb-8">
          <h2 className="text-2xl font-bold mb-4">Nossos Diferenciais</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-xl font-semibold mb-2">Produtos Certificados</h3>
              <p className="text-gray-700">
                Trabalhamos apenas com produtos que atendem às normas técnicas
                e possuem certificação de qualidade.
              </p>
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-2">Atendimento Técnico</h3>
              <p className="text-gray-700">
                Nossa equipe técnica está sempre pronta para auxiliar na
                escolha do produto ideal para sua necessidade.
              </p>
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-2">Entrega para Todo Brasil</h3>
              <p className="text-gray-700">
                Realizamos entregas para todo o território nacional,
                com agilidade e segurança.
              </p>
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-2">Garantia de Qualidade</h3>
              <p className="text-gray-700">
                Oferecemos garantia em todos os nossos produtos,
                assegurando sua satisfação.
              </p>
            </div>
          </div>
        </div>

        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Pronto para fazer negócio?</h2>
          <p className="text-gray-700 mb-6">
            Entre em contato conosco e descubra como podemos ajudar sua empresa.
          </p>
          <Link
            to="/contato"
            className="inline-block bg-blue-800 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 transition"
          >
            Fale Conosco
          </Link>
        </div>
      </div>
    </div>
  );
};

export default About;