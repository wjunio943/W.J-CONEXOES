import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { FaPhone, FaWhatsapp } from 'react-icons/fa';
import { Bars3Icon, XMarkIcon } from '@heroicons/react/24/outline';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <header>
      <div className="bg-blue-900 text-white py-2">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <div className="flex space-x-4">
            <a href="tel:+556299999999" className="flex items-center text-sm">
              <FaPhone className="mr-2" /> (62) 9999-9999
            </a>
            <a href="https://wa.me/556299999999" className="flex items-center text-sm">
              <FaWhatsapp className="mr-2" /> WhatsApp
            </a>
          </div>
          <div className="text-sm">
            Atendimento especializado em Goiás e todo o Brasil
          </div>
        </div>
      </div>

      <nav className="bg-white shadow-lg">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center h-16">
            <Link to="/" className="flex items-center">
              <span className="text-2xl font-bold text-blue-800">Logo</span>
            </Link>

            {/* Desktop Menu */}
            <div className="hidden md:flex space-x-8">
              <Link to="/" className="text-gray-700 hover:text-blue-800">Home</Link>
              <Link to="/produtos" className="text-gray-700 hover:text-blue-800">Produtos</Link>
              <Link to="/sobre" className="text-gray-700 hover:text-blue-800">Sobre</Link>
              <Link to="/contato" className="text-gray-700 hover:text-blue-800">Contato</Link>
              <Link to="/blog" className="text-gray-700 hover:text-blue-800">Blog</Link>
            </div>

            {/* Mobile Menu Button */}
            <div className="md:hidden">
              <button
                onClick={() => setIsOpen(!isOpen)}
                className="text-gray-700 hover:text-blue-800"
              >
                {isOpen ? (
                  <XMarkIcon className="h-6 w-6" />
                ) : (
                  <Bars3Icon className="h-6 w-6" />
                )}
              </button>
            </div>
          </div>

          {/* Mobile Menu */}
          {isOpen && (
            <div className="md:hidden">
              <div className="px-2 pt-2 pb-3 space-y-1">
                <Link
                  to="/"
                  className="block px-3 py-2 text-gray-700 hover:text-blue-800"
                  onClick={() => setIsOpen(false)}
                >
                  Home
                </Link>
                <Link
                  to="/produtos"
                  className="block px-3 py-2 text-gray-700 hover:text-blue-800"
                  onClick={() => setIsOpen(false)}
                >
                  Produtos
                </Link>
                <Link
                  to="/sobre"
                  className="block px-3 py-2 text-gray-700 hover:text-blue-800"
                  onClick={() => setIsOpen(false)}
                >
                  Sobre
                </Link>
                <Link
                  to="/contato"
                  className="block px-3 py-2 text-gray-700 hover:text-blue-800"
                  onClick={() => setIsOpen(false)}
                >
                  Contato
                </Link>
                <Link
                  to="/blog"
                  className="block px-3 py-2 text-gray-700 hover:text-blue-800"
                  onClick={() => setIsOpen(false)}
                >
                  Blog
                </Link>
              </div>
            </div>
          )}
        </div>
      </nav>
    </header>
  );
};

export default Navbar;